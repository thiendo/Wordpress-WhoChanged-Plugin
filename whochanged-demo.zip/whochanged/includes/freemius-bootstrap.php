<?php
/**
 * Demo package: Freemius disabled (no Account / Upgrade menus).
 *
 * @package WhoChanged
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'whochanged_fs' ) ) {
	/**
	 * @return null
	 */
	function whochanged_fs() {
		global $whochanged_fs;

		if ( isset( $whochanged_fs ) ) {
			return $whochanged_fs;
		}

		$whochanged_fs = null;

		return $whochanged_fs;
	}

	whochanged_fs();
	do_action( 'whochanged_fs_loaded' );
}
