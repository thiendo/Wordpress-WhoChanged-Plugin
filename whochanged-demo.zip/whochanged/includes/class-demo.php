<?php
/**
 * Playground demo package only (playground/demo-overlays/).
 * Never shipped in production builds.
 *
 * @package WhoChanged
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Demo-build behavior: locked Settings, Buy Now menu, PRO UX without Freemius.
 */
class WhoChanged_Demo {

	const BUY_URL = 'https://checkout.freemius.com/plugin/35452/';

	/**
	 * Register demo-only hooks (option write guard, settings POST block).
	 *
	 * @return void
	 */
	public static function init() {
		add_filter( 'pre_update_option', array( __CLASS__, 'block_settings_option' ), 10, 3 );
		add_action( 'admin_init', array( __CLASS__, 'block_settings_post' ), 1 );
	}

	/**
	 * @return bool Always true in the demo package.
	 */
	public static function is_enabled() {
		return true;
	}

	/**
	 * @return string
	 */
	public static function buy_url() {
		return esc_url_raw( (string) apply_filters( 'whochanged_demo_buy_url', self::BUY_URL ) );
	}

	/**
	 * Reject writes to WhoChanged settings options (even direct update_option calls).
	 *
	 * @param mixed  $value New value.
	 * @param string $option Option name.
	 * @param mixed  $old_value Previous value.
	 * @return mixed
	 */
	public static function block_settings_option( $value, $option, $old_value ) {
		$option = (string) $option;
		if ( 0 === strpos( $option, 'whochanged_pro_' ) || 'whochanged_delete_data_on_uninstall' === $option ) {
			return $old_value;
		}

		return $value;
	}

	/**
	 * Block any Settings form submission in the demo build.
	 *
	 * @return void
	 */
	public static function block_settings_post() {
		if ( ! is_admin() ) {
			return;
		}

		$mutating = array(
			'whochanged_pro_save',
			'whochanged_pro_purge_all',
			'whochanged_pro_send_test',
			'whochanged_pro_license_activate',
		);

		foreach ( $mutating as $key ) {
			if ( isset( $_POST[ $key ] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing -- demo hard block before handlers run.
				wp_die(
					esc_html__( 'Settings are disabled in the WhoChanged demo.', 'whochanged' ),
					esc_html__( 'Demo only', 'whochanged' ),
					array( 'response' => 403 )
				);
			}
		}
	}
}
