<?php
/**
 * Demo package: PRO UX always on, no Freemius / legacy license paths.
 *
 * @package WhoChanged
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! defined( 'WHOCHANGED_FS_PRODUCT_ID' ) ) {
	define( 'WHOCHANGED_FS_PRODUCT_ID', '' );
}

if ( ! defined( 'WHOCHANGED_FS_PUBLIC_KEY' ) ) {
	define( 'WHOCHANGED_FS_PUBLIC_KEY', '' );
}

require_once WHOCHANGED_PLUGIN_DIR . 'includes/freemius-bootstrap.php';

/**
 * PRO status for the public Playground demo build.
 */
class WhoChanged_Pro {

	/**
	 * @return bool
	 */
	public static function is_active() {
		return true;
	}

	/**
	 * @return bool
	 */
	public static function is_using_legacy_license() {
		return false;
	}
}
