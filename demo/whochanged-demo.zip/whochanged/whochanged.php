<?php
/**
 * Plugin Name: WhoChanged Demo
 * Plugin URI: https://douple.net/whochanged/
 * Description: Public Playground demo — settings disabled, live logging enabled.
 * Version: 1.1.0
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Author: Douple
 * Author URI: https://douple.net/
 * Text Domain: whochanged
 * Domain Path: /languages
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 *
 * Demo package bootstrap — copied over production whochanged.php by build-demo-zip.sh.
 *
 * @package WhoChanged
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'WHOCHANGED_VERSION', '1.1.0' );
define( 'WHOCHANGED_PLUGIN_FILE', __FILE__ );
define( 'WHOCHANGED_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'WHOCHANGED_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'WHOCHANGED_DEMO_MODE', true );

require_once WHOCHANGED_PLUGIN_DIR . 'includes/class-demo.php';
WhoChanged_Demo::init();

require_once WHOCHANGED_PLUGIN_DIR . 'includes/class-pro.php';

require_once WHOCHANGED_PLUGIN_DIR . 'includes/class-database.php';
require_once WHOCHANGED_PLUGIN_DIR . 'includes/class-activator.php';
require_once WHOCHANGED_PLUGIN_DIR . 'includes/class-deactivator.php';
require_once WHOCHANGED_PLUGIN_DIR . 'includes/class-event-normalizer.php';
require_once WHOCHANGED_PLUGIN_DIR . 'includes/class-mapper.php';
require_once WHOCHANGED_PLUGIN_DIR . 'includes/class-diff.php';
require_once WHOCHANGED_PLUGIN_DIR . 'includes/class-logger.php';
require_once WHOCHANGED_PLUGIN_DIR . 'includes/class-hooks.php';
require_once WHOCHANGED_PLUGIN_DIR . 'includes/class-admin.php';

register_activation_hook( __FILE__, array( 'WhoChanged_Activator', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'WhoChanged_Deactivator', 'deactivate' ) );

/**
 * Bootstrap plugin.
 *
 * @return void
 */
function whochanged_init() {
	load_plugin_textdomain( 'whochanged', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
	WhoChanged_Database::maybe_upgrade_schema();

	if ( ! wp_next_scheduled( 'whochanged_pro_cleanup_logs' ) ) {
		wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'whochanged_pro_cleanup_logs' );
	}

	$logger = new WhoChanged_Logger();
	$hooks  = new WhoChanged_Hooks( $logger );
	$admin  = new WhoChanged_Admin( $logger );

	$hooks->register();
	$admin->register();
}
add_action( 'plugins_loaded', 'whochanged_init' );

define( 'WHOCHANGED_FREE_RETENTION_DAYS', 30 );

/**
 * Demo: keep unlimited retention (no automatic purge during Playground session).
 *
 * @return void
 */
function whochanged_pro_cleanup_logs_cron() {
	if ( WhoChanged_Pro::is_active() ) {
		return;
	}
}
add_action( 'whochanged_pro_cleanup_logs', 'whochanged_pro_cleanup_logs_cron' );
